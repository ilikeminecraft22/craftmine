import socket
print("server address: ", socket.gethostbyname(socket.getfqdn()))
print("server address: ", socket.gethostbyname(socket.getfqdn()))
print("server address: ", socket.gethostbyname(socket.getfqdn()))
print("server address: ", socket.gethostbyname(socket.getfqdn()))
print("server address: ", socket.gethostbyname(socket.getfqdn()))
print("server address: ", socket.gethostbyname(socket.getfqdn()))
from panda3d.core import loadPrcFileData
loadPrcFileData('', 'window-type none')
loadPrcFileData('', 'fullscreen 0')
loadPrcFileData('', 'undecorated 0')
loadPrcFileData('', 'win-origin 100 100')
loadPrcFileData('', 'win-size 1280 720')

from ursina import *

app = Ursina(title="Craftmine Alpha 1.0.0", vsync=False)
window.borderless = False
window.fullscreen = False
window.exit_button.visible = False
window.title_bar = True
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.shaders import lit_with_shadows_shader
from ursinanetworking import *

# === App Setup ===

# === Networking Setup ===
Server = UrsinaNetworkingServer("0.0.0.0", 25565)
Client = UrsinaNetworkingClient("localhost", 25565)
ezServer = EasyUrsinaNetworkingServer(Server)

# === Player & World ===
plr = FirstPersonController()
Sky()
app.backface_culling = True

light = DirectionalLight(shadows=True)
light.position = Vec3(64, 24, 0)
light.look_at(Vec3(0, 0.5, 64))

# === Global State ===
buildblock = 0
boxes = []

# === Block Textures & Colors ===
block_textures = ['assets\grass.jpg', 'assets\planks.jpg', 'assets\stone.jpg', 'assets\brick.jpg', 'assets\glass.png']
block_colors = [color.white, color.white, color.white, color.white, color.rgba(255, 255, 255, 40)]

# === Ground Platform (not destroyable) ===
ground_box = Button(
    color=color.rgba(255, 255, 255, 85),
    position=(0, 0, 0),
    model='cube',
    parent=scene,
    origin_y=0.5,
    scale=64,
    collider='box',
    shader=lit_with_shadows_shader
)

# === Spawn New Block ===
def spawn_block(block_type, position):
    print(f"[Spawn] Placing block type {block_type} at {position}")
    new = Button(
        color=block_colors[block_type],
        position=position,
        model='cube',
        texture=block_textures[block_type],
        parent=scene,
        origin_y=0.5,
        collider='box',
        shader=lit_with_shadows_shader,
        highlight_color=color.light_gray
    )
    boxes.append(new)

# === Destroy Block at Position ===
def destroy_block_at(position):
    for b in boxes:
        print(f"[Check] {b.position} vs {position}")
        if b.position == position:
            print(f"[Destroy] Destroying block at {position}")
            destroy(b)
            boxes.remove(b)
            break

# === Server Events ===
@Server.event
def request_place_block(conn, data):
    pos, block_type = data
    print(f"[Server] Received request to place block at {pos}")
    Server.broadcast("place_block", (pos, block_type))

@Server.event
def request_destroy_block(conn, pos):
    print(f"[Server] Received request to destroy block at {pos}")
    Server.broadcast("destroy_block", pos)

# === Client Events ===
@Client.event
def place_block(data):
    pos, block_type = data
    print(f"[Client] Placing block at {pos}")
    spawn_block(block_type, pos)

@Client.event
def destroy_block(pos):
    print(f"[Client] Received destroy command at {pos}")
    destroy_block_at(pos)

# === Input Handling ===
def input(key):
    global buildblock
    if key == ".":
        app.screenshot("craftmine-screenshot")

    if key == "v":
        plr.enabled = not plr.enabled

    if key == "x":
        buildblock = (buildblock + 1) % len(block_textures)
        print(f"[Input] Switched to block type {buildblock}")

    for b in boxes:
        if b.hovered:
            if key == "left mouse down":
                if b != ground_box:
                    print(f"[Input] Requesting destroy at {b.position}")
                    Client.send_message("request_destroy_block", b.position)
            elif key == "right mouse down":
                if b != ground_box:
                    place_position = b.position + mouse.normal
                    print(f"[Input] Requesting place at {place_position}")
                    Client.send_message("request_place_block", (place_position, buildblock))

# === Game Update Loop ===
def update():
    Client.process_net_events()
    Server.process_net_events()

# === Spawn a Starting Block to Test ===
spawn_block(0, Vec3(0, 1, 0))

app.run()
